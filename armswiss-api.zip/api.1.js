//Proposed configuration for API used by Angular app
const express = require('express');
const jwt = require('jsonwebtoken');
require('dotenv').config();
const cors = require('cors');
const router = express.Router();
const api = require('./routes/api');
const ZCRMRestClient = require('zcrmsdk');
const fs = require('fs');



var refresh_token = '';
const app = express();
var token = app.get('access_token');
const PORT = 3030;
app.use(cors());

app.use(express.json());

const utils = require('./utils.js');
const allocatorsRouter = require('./routes/allocators');
const accountsRouter = require('./routes/accounts');
const adminRouter = require('./routes/admin');
app.use('/allocators', allocatorsRouter);
app.use('/accounts', accountsRouter);
app.use('/admin', adminRouter);
const db = utils.createDBConnection();
const bcrypt = require("bcryptjs");
try {
 
    //const { email, password } = req.body;
    const { email, password } = {email:'khomotso@geminisolution.co.za', password: 'hahahaha'};
   // let hashedPassword = await bcrypt.hash(password, 8);
    let accountId = '1185106000019416001'; //this will be set from zoho account id that the user belongs to



    bcrypt.hash(password, 8, (err, hash) => {
       
            db.query('INSERT INTO users SET ?', {email: email, password: hash, accountId: accountId }, (error) => {
                if(error) {
                    console.log(error)
                } else {
                    return res.status(200).json({
                        message: 'User registered'
                    })
                }  
                
            });
      });


    
} catch(error) {
    console.log(error);
}